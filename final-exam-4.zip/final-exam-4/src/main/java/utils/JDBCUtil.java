package utils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtil {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/final_exam";
        String user = "root";
        String password = "root";
        return DriverManager.getConnection(url, user, password);
    }

    public static void checkConnection() {
        try (Connection connection = getConnection()) {
            if (connection == null) {
                System.out.println("Kết nối thất bại.");
            } else {
                System.out.println("Kết nối thành công: " + connection.getCatalog());
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
