package backend.service;

import backend.repository.UserRepository;
import entity.User;

import java.sql.SQLException;
import java.util.List;

public class UserService {
    private UserRepository repository = new UserRepository();

    public List<User> findAll() throws SQLException {
        return repository.findAll();
    }
    public User findByEmailAndPassWord(String email, String password) throws SQLException {
        return repository.findByEmailAndPassWord(email, password);
    }
    public User findById(int id) throws SQLException {
        return repository.findById(id);
    }

    public int create(User user) throws SQLException {
        return repository.create(user);
    }

    public int update(User user) throws SQLException {
        return repository.update(user);
    }

    public int deleteById(int id) throws SQLException {
        return repository.deleteById(id);
    }
}
