package backend.controller;
import backend.service.UserService;
import entity.User;

import java.sql.SQLException;
import java.util.List;

public class UserController {
    private UserService service = new UserService();

    public List<User> findAll() throws SQLException {
        return service.findAll();
    }

    public User findById(int id) throws SQLException {
        return service.findById(id);
    }
    public User findByEmailAndPassWord(String email, String password) throws SQLException {
        return service.findByEmailAndPassWord(email, password);
    }
    public int create(User user) throws SQLException {
        return service.create(user);
    }

    public int update(User user) throws SQLException {
        return service.update(user);
    }

    public int deleteById(int id) throws SQLException {
        return service.deleteById(id);
    }
}
